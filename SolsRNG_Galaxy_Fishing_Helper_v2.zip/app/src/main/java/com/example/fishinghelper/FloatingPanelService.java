package com.example.fishinghelper;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager windowManager;
    private View panel;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(10, 8, 10, 8);
        box.setBackgroundColor(0xEEFFFFFF);

        TextView title = new TextView(this);
        title.setText("🎣 낚시 보조");
        title.setTextColor(0xFF111111);
        title.setTextSize(14);
        box.addView(title);

        Button start = new Button(this);
        start.setText("반복 터치 시작");
        start.setOnClickListener(v -> TapAccessibilityService.startTapping());
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("중지");
        stop.setOnClickListener(v -> TapAccessibilityService.stopTapping());
        box.addView(stop);

        Button close = new Button(this);
        close.setText("패널 닫기");
        close.setOnClickListener(v -> stopSelf());
        box.addView(close);

        panel = box;
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 20;
        params.y = 160;
        windowManager.addView(panel, params);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }

    @Override public void onDestroy() {
        TapAccessibilityService.stopTapping();
        if (panel != null && windowManager != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

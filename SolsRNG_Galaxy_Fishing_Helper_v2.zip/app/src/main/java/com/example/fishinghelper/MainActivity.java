package com.example.fishinghelper;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText intervalInput, xInput, yInput;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 28, 28, 20);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("🎣 Fishing Helper v2");
        title.setTextSize(25);
        title.setPadding(0, 0, 0, 12);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("지정한 위치를 반복 터치하고, 게임 위에 작은 시작/중지 패널을 표시해요. 움직이는 낚시 타이밍은 자동 인식하지 못합니다.");
        info.setTextSize(15);
        info.setPadding(0, 0, 0, 12);
        layout.addView(info);

        intervalInput = addField(layout, "반복 간격(ms, 최소 500)", "1500");
        xInput = addField(layout, "터치 X 좌표(픽셀)", "540");
        yInput = addField(layout, "터치 Y 좌표(픽셀)", "1600");

        Button access = new Button(this);
        access.setText("1. 접근성 설정 열기");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(access);

        Button overlay = new Button(this);
        overlay.setText("2. 다른 앱 위에 표시 권한");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else Toast.makeText(this, "권한이 이미 허용되어 있어요.", Toast.LENGTH_SHORT).show();
        });
        layout.addView(overlay);

        Button show = new Button(this);
        show.setText("3. 플로팅 패널 표시");
        show.setOnClickListener(v -> {
            try {
                long interval = Math.max(500, Long.parseLong(intervalInput.getText().toString().trim()));
                int x = Integer.parseInt(xInput.getText().toString().trim());
                int y = Integer.parseInt(yInput.getText().toString().trim());
                TapAccessibilityService.configure(interval, x, y);
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "먼저 '다른 앱 위에 표시' 권한을 허용해 주세요.", Toast.LENGTH_LONG).show();
                    return;
                }
                startService(new Intent(this, FloatingPanelService.class));
                Toast.makeText(this, "플로팅 패널을 띄웠어요. Roblox로 전환하세요.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "간격과 좌표를 숫자로 입력해 주세요.", Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(show);

        Button stop = new Button(this);
        stop.setText("전체 중지");
        stop.setOnClickListener(v -> {
            TapAccessibilityService.stopTapping();
            stopService(new Intent(this, FloatingPanelService.class));
            Toast.makeText(this, "중지했어요.", Toast.LENGTH_SHORT).show();
        });
        layout.addView(stop);

        TextView note = new TextView(this);
        note.setText("\n주의: 처음에는 게임이 아닌 화면에서 테스트하세요. 좌표는 화면 크기/방향에 따라 달라져요. 계정 정보는 입력하지 마세요.");
        note.setTextSize(13);
        layout.addView(note);
        setContentView(layout);
    }

    private EditText addField(LinearLayout layout, String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setPadding(0, 8, 0, 0);
        layout.addView(tv);
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setInputType(2);
        edit.setText(value);
        layout.addView(edit);
        return edit;
    }
}

package com.example.fishinghelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class TapAccessibilityService extends AccessibilityService {
    private static TapAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private long intervalMs = 1500;
    private int tapX = 540, tapY = 1600;

    public static void configure(long interval, int x, int y) {
        if (instance != null) {
            instance.intervalMs = Math.max(500, interval);
            instance.tapX = Math.max(0, x);
            instance.tapY = Math.max(0, y);
        }
    }

    public static void startTapping() {
        if (instance != null) {
            instance.running = true;
            instance.handler.removeCallbacks(instance.tapRunnable);
            instance.handler.post(instance.tapRunnable);
        }
    }

    public static void stopTapping() {
        if (instance != null) {
            instance.running = false;
            instance.handler.removeCallbacks(instance.tapRunnable);
        }
    }

    private final Runnable tapRunnable = new Runnable() {
        @Override public void run() {
            if (!running) return;
            Path path = new Path();
            path.moveTo(tapX, tapY);
            GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 70);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
            dispatchGesture(gesture, null, null);
            handler.postDelayed(this, intervalMs);
        }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopTapping(); }
    @Override public void onDestroy() {
        stopTapping();
        instance = null;
        super.onDestroy();
    }
}
